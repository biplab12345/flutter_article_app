package com.example.flutter_article_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
