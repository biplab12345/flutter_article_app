import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/article.dart';
import '../services/api_service.dart';

class ArticleController extends GetxController {
  var articles = <Article>[].obs;
  var filteredArticles = <Article>[].obs;
  var favorites = <int>[].obs;
  var isLoading = true.obs;
  var errorMessage = ''.obs;

  @override
  void onInit() {
    super.onInit();
    loadFavorites();
    fetchArticles();
  }

  void fetchArticles() async {
    try {
      isLoading(true);
      errorMessage('');
      final result = await ApiService.fetchArticles();
      articles.value = result;
      filteredArticles.value = result;
    } catch (e) {
      errorMessage(e.toString());
    } finally {
      isLoading(false);
    }
  }

  void searchArticles(String query) {
    filteredArticles.value = articles.where((a) =>
      a.title.toLowerCase().contains(query.toLowerCase()) ||
      a.body.toLowerCase().contains(query.toLowerCase())
    ).toList();
  }

  void toggleFavorite(int id) async {
    if (favorites.contains(id)) {
      favorites.remove(id);
    } else {
      favorites.add(id);

    }
    final prefs = await SharedPreferences.getInstance();
    prefs.setStringList('favorites', favorites.map((e) => e.toString()).toList());
  }

void loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final favList = prefs.getStringList('favorites') ?? [];
    favorites.value = favList.map((e) => int.parse(e)).toList();
  }

  bool isFavorite(int id) => favorites.contains(id);
}