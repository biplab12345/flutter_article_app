import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/article_controller.dart';
import 'detail_screen.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<ArticleController>();
    final favorites = controller.articles.where((a) => controller.favorites.contains(a.id)).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Favorites')),
      body: ListView.builder(
        itemCount: favorites.length,
        itemBuilder: (context, index) {
          final article = favorites[index];
          return Card(
            child: ListTile(
              title: Text(article.title),
              subtitle: Text(article.body, maxLines: 2, overflow: TextOverflow.ellipsis),
              onTap: () => Get.to(() => DetailScreen(article: article)),
            ),
          );
        },
      ),
    );
  }
}