import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/article_controller.dart';
import 'detail_screen.dart';
import 'favorites_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<ArticleController>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Articles'),
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite),
            onPressed: () => Get.to(() => const FavoritesScreen()),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        } else if (controller.errorMessage.isNotEmpty) {
          return Center(child: Text(controller.errorMessage.value));
        } else {
          return RefreshIndicator(
            onRefresh: () async => controller.fetchArticles(),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    decoration: const InputDecoration(
                      labelText: 'Search',
                      prefixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(),
                    ),
                    onChanged: controller.searchArticles,
                  ),
                ),

                     Expanded(
                      child: ListView.builder(
                        itemCount: controller.filteredArticles.length,
                        itemBuilder: (context, index) {
                          final article = controller.filteredArticles[index];
                          return Card(
                            child: ListTile(
                              title: Text(article.title),
                              subtitle: Text(article.body, maxLines: 2, overflow: TextOverflow.ellipsis),
                              trailing: Obx(() {
                                  return IconButton(
                                    icon: Icon(
                                      controller.isFavorite(article.id)? Icons.favorite : Icons.favorite_border,
                                      color: controller.favorites.contains(article.id)
                                          ? Colors.red
                                          : null,
                                    ),
                                    onPressed: () => controller.toggleFavorite(article.id),
                                  );
                                }
                              ),
                              onTap: () => Get.to(() => DetailScreen(article: article)),
                            ),
                          );
                        },
                      ),
                    )


              ],
            ),
          );
        }
      }),
    );
  }
}